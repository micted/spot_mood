def spotify_playlists():
    playlists = {'on_repeat': 'https://open.spotify.com/playlist/37i9dQZF1EphFJMoIJktEw?si=ad5db46986644e23'}
    return playlists


def personal_playlists():
    playlists = {'drive_hood': 'spotify:playlist:1uM1laLmdeCMRQoYC1gybB'}
    return playlists

